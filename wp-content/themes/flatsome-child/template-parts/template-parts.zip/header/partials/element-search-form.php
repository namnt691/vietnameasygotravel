<li class="header-search-form search-form html relative has-icon">
	<div class="header-search-form-wrapper">
		<?php echo do_shortcode('[search style="'.flatsome_option('header_search_form_style').'"]'); ?>
	</div>
</li>